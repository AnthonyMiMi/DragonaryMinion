Copy and paste everything in the zip file to the folder where main.exe is located, and confirm overwrite.

把文件夹内所有文件复制黏贴到 main.exe所在的文件夹，并确认覆盖。